package novo;
import java.util.Scanner;
public class atividade{

	private static Scanner inserir;

public static void main (String[] args) {
	int soma, subtra��o,multiplica��o,divis�o,pot�ncia, escolha;
	double numero1, numero2;

	inserir = new Scanner(System.in);
	System.out.println("OPERA��ES D�SPONIVEIS");
	System.out.println("1-> SOMA");
	System.out.println("2-> DIVIS�O");
	System.out.println("3-> SUBTRA��O");
	System.out.println("4-> MULTIPLICA��O");
	System.out.println("5-> POT�NCIA");
	System.out.println("0-> SAIR");
	System.out.println("Digite a op��o desejada:");
	escolha = inserir.nextInt();
	
	switch(escolha){
	case 1:
		System.out.println("Digite um valor\n");
		numero1 = inserir.nextDouble();
		System.out.println("Digite um valor\n");
		numero2 = inserir.nextDouble();soma = (int) (numero1+numero2);
	System.out.print("Resposta:"+soma);
	break;
	case 2:System.out.println("Digite um valor\n");
	numero1 = inserir.nextDouble();
	System.out.println("Digite um valor\n");
	numero2 = inserir.nextDouble();
		divis�o=  (int)(numero1/numero2);
	System.out.print("Resposta:"+divis�o);
	break;
	case 3:System.out.println("Digite um valor\n");
	numero1 = inserir.nextDouble();
	System.out.println("Digite um valor\n");
	numero2 = inserir.nextDouble();
		subtra��o= (int)(numero1-numero2);
	System.out.print("Resposta:"+subtra��o);
	break;
	case 4:System.out.println("Digite um valor\n");
	numero1 = inserir.nextDouble();
	System.out.println("Digite um valor\n");
	numero2 = inserir.nextDouble();
		multiplica��o= (int)(numero1*numero2);
	System.out.print("Resposta:"+multiplica��o);
	break;
	
	case 5: System.out.println("Informe o valor:");
	numero1= inserir.nextDouble();
	pot�ncia = (int) Math.pow(numero1,2);
	System.out.print("Resposta:"+pot�ncia);
	break;
	case 0:
		System.out.println("Fechando...");
}
	 while(escolha!=0);
		inserir.close();
		
	}
	

		
	}

	
	
	
	

